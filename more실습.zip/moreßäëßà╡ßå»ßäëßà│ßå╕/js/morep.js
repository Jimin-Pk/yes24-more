$(function(){
    function listMore(){
        let size_li = $('#trdseller_box li').size();
        win=$(window).width();
        if(win <= 680){
            let  x=2;
            $('#trdseller_box li:lt('+x+')').show();            
            $('.more_btn').click(function(){
            x= (x+2 <= size_li) ? x+2 : size_li;
                $('#trdseller_box li:lt('+x+')').show();
            });
       }else if(win>680 && win<=1080)
        {
             let  x=3;
             $('#trdseller_box li:lt('+x+')').show();      
             $('.more_btn').click(function () {
             x= (x+3 <= size_li) ? x+3 : size_li;
             $('#trdseller_box li:lt('+x+')').show();
             });        
         } else{
            let  x=4;
            $('#trdseller_box li:lt('+x+')').show();
            $('.more_btn').click(function(){
            x= (x+4 <= size_li) ? x+4 : size_li;
            $('#trdseller_box li:lt('+x+')').show();
           });
        } 
    }
    
    listMore();

    $(window).on("resize",function(){
        listMore()
        location.reload();
    });
});
